package fitpeo.utilities;

import java.io.FileReader;
import java.util.Properties;

import org.testng.annotations.Test;

public class propertiesHandler {
	@Test
	public static String gettingkeys (String key) throws Exception {
	String path=System.getProperty("user.dir")+"\\src\\main\\resources\\data.properties";
	FileReader file=new FileReader (path);
	Properties p=new Properties();
	p.load(file);
	return p.getProperty(key);
}
}