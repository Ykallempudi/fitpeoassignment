package fitpeo.testCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TestCases extends TestCasesHelperClass  {
	
	public static String total_recurring_reimbursement;
	public static String text;
	public static SoftAssert asert=new SoftAssert();
	
	@Test(testName="Navigate to the fitpeo homepage")
	public static void fitpeo_tc001() throws Exception {
		browser_Setup();			
	}
	
	@Test(testName="Navigate to the revenue calculator page")
	public static void fitpeo_tc002() {
		driver.findElement(By.linkText("Revenue Calculator")).click();
	}
	
	@SuppressWarnings("deprecation")
	@Test(testName="scroll down to the slider section")
	public static void fitpeo_tc003() {
		
	    Actions ac=new Actions(driver);
	    driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		WebElement element=driver.findElement(By.xpath("//span[@class='MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary css-1sfugkh']"));
		ac.scrollToElement(element).perform();		
	}
	
	
	
	@Test(testName="adjust the slider")
	public static void fitpeo_tc004()
	{
	    int expected=slideAdjuster(820);
	    asert.assertEquals(820, expected);
	}
	
	@Test(testName="update the text feild")
	public static void fitpeo_tc005() throws InterruptedException {
		keyBoardActions("560");
	}
	
	
	
	@Test(testName="validate the slider value")
	public static void fitpeo_tc006() throws InterruptedException {
		
		String value=driver.findElement(By.xpath("//input[@data-index=\"0\"]")).getAttribute("value");
		int expected_value=Integer.valueOf(value);
		asert.assertEquals(560,expected_value );
		keyBoardActions("820");
	}
	
	@Test(testName="select CPT codes")
	public static void fitpeo_tc007() {
		driver.findElement(By.xpath("//span[text()=57]/preceding::input[@type=\"checkbox\"]")).click();
		driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[2]")).click();
		driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[3]")).click();
		driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[8]")).click();
	}
	
	@SuppressWarnings("deprecation")
	@Test(testName="validate total reccuring reimbursement")
	public static void fitpeo_tc008() {
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		text="Total Recurring Reimbursement for all Patients Per Month:";
		WebElement element=driver.findElement(By.xpath("//p[text()=\"Total Recurring Reimbursement for all Patients Per Month:\"]/following::p[text()=\"110700\"]"));
		
		asert.assertEquals(true, element.isDisplayed(),"Element not present");
		
		total_recurring_reimbursement=element.getText();
		System.out.println(total_recurring_reimbursement);
		
	}
	
	@Test(testName="verify the header display")
	public static void fitpeo_tc009() {	
		String Actual="Total Recurring Reimbursement for all Patients Per Month:$110700";
		System.out.println(text+total_recurring_reimbursement);
		String expected=text+total_recurring_reimbursement;
		asert.assertEquals(Actual, expected,"Error while verifying header details");
		
		driver.close();
	}
}