package fitpeo.testCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import fitpeo.utilities.browsersetup;

public class TestCasesHelperClass extends browsersetup {
	
	@SuppressWarnings("deprecation")
	public static void keyBoardActions(String value) {
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		WebElement textfield =driver.findElement(By.xpath("//input[contains(@class,'MuiInputBase-input M')]"));
		textfield.click();
		 Actions actions = new Actions(driver);
	     actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform();
	     driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		textfield.sendKeys(value);
	}
	
	public static int slideAdjuster(int value)
	{
		WebElement element = driver.findElement(By.xpath("//input[@data-index='0' and @aria-valuemax='2000']"));
	    Actions action = new Actions(driver);
	        action.clickAndHold(element)
	                .moveByOffset(94, 0) // Move horizontally
	                .release()
	                .perform();
	        WebElement textfield =driver.findElement(By.xpath("//input[contains(@class,'MuiInputBase-input M')]"));
	    	String a=textfield.getAttribute("value");
	    	int position=Integer.parseInt(a);
	        while (position != value) {
	            if (position > value) { 
	                Actions actions = new Actions(driver);
	                actions.sendKeys(Keys.ARROW_LEFT).perform();
	                position--;  
	            } else if (position < value) {
	                Actions actions = new Actions(driver);
	                actions.sendKeys(Keys.ARROW_RIGHT).perform();
	                position++;
	            }}
	    	int expected=Integer.parseInt(textfield.getAttribute("value"));    	
	    	return expected;
	}
}
